const BaseCommand = require('../../utils/structures/BaseCommand');
const accountSid = "AC4af05b8c7d814d1041e1f51fa553c63b";
const authToken = "aa8bf377a17d2941f7bf91a449570aac";
const tc = require('twilio')(accountSid, authToken);
module.exports = class StatusCommand extends BaseCommand {
  constructor() {
    super('status', 'otp', []);
  }

  run(client, message, args) {
    var sid = args[0];
    if(client.calls.get(sid)) {
      tc.calls(sid)
        .fetch()
        .then((items) => {
          return message.channel.send(`
Call with ID: "${sid}"

Status: ${items.status}
Code: ${client.calls.get(sid).code}
To: ${items.to} 
Duration: ${items.duration}
          `)
        })
    }
  }
}