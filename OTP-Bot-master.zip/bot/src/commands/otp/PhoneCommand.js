require("dotenv").config()
const BaseCommand = require('../../utils/structures/BaseCommand');
const { MessageEmbed } = require("discord.js")
const call = require("../../../../caller").chase
const { parsePhoneNumber } = require("libphonenumber-js")
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require('twilio')(accountSid, authToken);


module.exports = class CotpCommand extends BaseCommand {
  constructor() {
    super('ph', 'otp', ['phone']);
  }

  async run(client, message, args) {
    

    client.lookups.phoneNumbers('(510) 867-5310')
                 .fetch({countryCode: 'US'})
                 .then(phone_number => console.log(phone_number.phoneNumber));

      return message.channel.send('Command completed')

      
  }
}